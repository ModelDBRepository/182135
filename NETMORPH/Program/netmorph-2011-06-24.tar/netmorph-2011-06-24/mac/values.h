/* values.h for Mac */
/* Randal A. Koene, 20070208 */

#include <float.h>

#define MAXDOUBLE DBL_MAX

#define MINDOUBLE DBL_MIN

