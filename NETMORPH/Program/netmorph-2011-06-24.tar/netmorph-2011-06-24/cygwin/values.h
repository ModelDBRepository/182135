/* values.h for Cygwin */
/* Randal A. Koene, 20070209 */

#include <float.h>

#define MAXDOUBLE DBL_MAX

#define MINDOUBLE DBL_MIN

